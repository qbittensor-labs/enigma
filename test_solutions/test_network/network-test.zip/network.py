"""Outbound network smoke test: GET a URL that resolves outside the container."""

from __future__ import annotations

import os
import sys
import urllib.error
import urllib.request


def main() -> int:
    url = os.environ.get("NETWORK_TEST_URL", "https://example.com/")
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=15) as resp:
            status = resp.getcode()
            chunk = resp.read(512)
    except urllib.error.HTTPError as exc:
        print(f"HTTP error: {exc.code} {exc.reason}", file=sys.stderr)
        return 1
    except urllib.error.URLError as exc:
        print(f"URL error: {exc.reason}", file=sys.stderr)
        return 1
    except TimeoutError:
        print("Request timed out", file=sys.stderr)
        return 1

    print(f"OK: GET {url} -> {status}, read {len(chunk)} bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
