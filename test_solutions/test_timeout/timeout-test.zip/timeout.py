"""Run until killed (for timeout / watchdog tests)."""

import time

while True:
    time.sleep(3600)
