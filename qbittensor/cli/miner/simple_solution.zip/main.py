# main.py
import os
from time import sleep, time
from datetime import timedelta


def main():
    
	setup_input_file = "/challenge_input/challenge_input.txt"
	# Read the input file
	try:
		with open(setup_input_file, "r") as f:
			input_data = f.read()
		print(f"✅ Successfully read input file: {setup_input_file}")
		print(f"📄 Input data: {input_data}")
  
	except Exception as e:
		print(f"❌ Error reading input file: {e}")
		return

	for i in range(90):
		print(f"Some logging idx {i}")
		sleep(timedelta(seconds=1).total_seconds())

	output_text = "Hello from inside the Docker container! 🐳"

	# Write output to a file
	output_dir = "/output/solution_artifacts"
	os.makedirs(output_dir, exist_ok=True)
	with open(f"{output_dir}/output.txt", "w") as f:
		f.write(output_text)

	print("✅ Output written to /output/solution_artifacts/output.txt")

if __name__ == "__main__":
	main()
